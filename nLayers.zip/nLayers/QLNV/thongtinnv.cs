﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLNV
{
    //class thongtinnv
    //{
    //    public int Manv { get; set; }

    //    public string Tennv { get; set; }

    //    public string Chucvu { get; set; }

    //    public string Phongban { get; set; }

    //    public string Chuthich { get; set; }

    //}
}
